<?php
// Heading
$_['heading_title'] 				= 'Options Image';

// Entry
$_['entry_product_popup_element']	= 'Product Popup Element';
$_['entry_product_popup_attr']		= 'Product Popup Attribute';
$_['entry_product_thumb_element']	= 'Product Thumb Element';
$_['entry_product_thumb_attr']		= 'Product Thumb Attribute';

// Text
$_['text_extension']				= 'Extensions';
$_['text_success']     				= 'Success: You have modified module!';
$_['text_edit']        				= 'Edit Options Image Module';
$_['text_version']   				= 'Version:';

// Button
$_['button_apply'] 					= 'Apply';

// Error
$_['error_permission']				= 'Warning: You do not have permission to modify Options Image module!';