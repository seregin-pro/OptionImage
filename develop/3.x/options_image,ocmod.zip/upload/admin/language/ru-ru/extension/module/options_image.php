<?php
// Heading
$_['heading_title'] 				= 'Смена изображения товара при выборе опции';

// Entry
$_['entry_product_popup_element']	= 'Селектор основного изображения во всплывающем окне';
$_['entry_product_popup_attr']		= 'Атрибут основного изображения во всплывающем окне';
$_['entry_product_thumb_element']	= 'Селектор основного изображения товара';
$_['entry_product_thumb_attr']		= 'Атрибут основного изображения товара';

// Text
$_['text_extension']				= 'Расширения';
$_['text_success']					= 'Настройки успешно изменены!';
$_['text_edit']						= 'Настройки модуля';
$_['text_version']					= 'Версия:';

// Button
$_['button_apply'] 	    			= 'Применить';

// Error
$_['error_permission']				= 'У Вас нет прав для управления данным модулем!';